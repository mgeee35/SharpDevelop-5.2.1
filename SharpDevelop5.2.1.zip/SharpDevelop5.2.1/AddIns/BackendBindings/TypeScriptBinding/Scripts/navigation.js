﻿
ls.refresh(true);
var items = ls.getNavigationBarItems(host.fileName);
host.updateNavigationBarItems(items);